#!/usr/bin/env bash

DATA='{ "value1" : "'$KMPARAM_Value_1'" , "value2" : "'$KMPARAM_Value_2'", "value3" : "'$KMPARAM_Value_3'" }';

RESP=$(curl -s -H "Content-Type: application/json" \
	-w "%{http_code}\n" \
	-X POST \
	-d "$DATA" \
	https://maker.ifttt.com/trigger/$KMPARAM_Event/with/key/$KMPARAM_Key);

# Response Code
CODE="$(echo "${RESP}" | grep -o -E '[0-9]{3}$')";

# Response (with code removed)
RESP="$(echo "${RESP}" | tr -d "${CODE}")";

echo $RESP;